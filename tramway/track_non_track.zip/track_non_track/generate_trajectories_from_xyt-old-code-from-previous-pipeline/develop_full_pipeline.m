


%path_all = '/Users/jbmasson/Dropbox (HHMI)/Path_to_all_programs_sync_hhmi/Matlab_for_cluster_app/recreate_trajectories_from_xyt';
path_all = '/Users/jbmasson/Dropbox (HHMI)/Path_to_all_programs_sync_hhmi/Matlab_for_cluster_app/';


copy_file_and_all_dependencies_in_folder('generate_trajectories_from_xyt', 'generate_trajectories_from_xyt',...
    path_all, {});