function traj = renumber_trajs(traj);


number = trajs(:,1);




